require 'puppet/application/indirection_base'

class Puppet::Application::Node < Puppet::Application::IndirectionBase
end
