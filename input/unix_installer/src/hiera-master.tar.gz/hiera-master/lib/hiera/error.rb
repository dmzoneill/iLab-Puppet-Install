class Hiera
  class Error < StandardError; end
  class InvalidConfigurationError < Error; end
end
